(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(main)_layout_tsx_cdcca6a9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(main)_layout_tsx_cdcca6a9._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_5ac40801._.js",
    "static/chunks/node_modules_f01e2ed1._.js",
    "static/chunks/src_a7196617._.js"
  ],
  "source": "dynamic"
});
