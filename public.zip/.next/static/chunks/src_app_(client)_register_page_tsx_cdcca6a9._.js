(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(client)_register_page_tsx_cdcca6a9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(client)_register_page_tsx_cdcca6a9._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_4685f21f._.js",
    "static/chunks/node_modules_next_90d0290a._.js",
    "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
    "static/chunks/node_modules_motion_dist_es_815661c9._.js",
    "static/chunks/node_modules_axios_lib_99999129._.js",
    "static/chunks/node_modules_de86c289._.js",
    "static/chunks/src_406846f0._.js"
  ],
  "source": "dynamic"
});
