(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(main)_dashboard_page_tsx_15516784._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(main)_dashboard_page_tsx_15516784._.js",
  "chunks": [
    "static/chunks/node_modules_lodash_b24d3603._.js",
    "static/chunks/node_modules_recharts_es6_53ac68f1._.js",
    "static/chunks/node_modules_1c0dc6c7._.js",
    "static/chunks/src_ffd55d79._.js"
  ],
  "source": "dynamic"
});
