(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(main)_page_tsx_15516784._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(main)_page_tsx_15516784._.js",
  "chunks": [
    "static/chunks/node_modules_f2a82f27._.js",
    "static/chunks/src_app_(main)_page_tsx_bdf01277._.js"
  ],
  "source": "dynamic"
});
